Backend (Spring Boot + H2 file)

- Dependencies: Web, JPA, Validation, Lombok, H2.
- REST endpoints:
  - GET /api/cv/{id} -> trả JSON payload
  - PUT /api/cv/{id} -> lưu JSON payload
- CORS bật cho http://localhost:5500 (hoặc nơi bạn serve FE).

Chạy backend:

```
cd backend
mvn spring-boot:run
```

application.properties dùng H2 file (dữ liệu lưu ở ./data/cvdb):

```
server.port=8080
spring.datasource.url=jdbc:h2:file:./data/cvdb;DB_CLOSE_DELAY=-1;AUTO_SERVER=TRUE
spring.datasource.username=sa
spring.datasource.password=
spring.datasource.driver-class-name=org.h2.Driver
spring.jpa.hibernate.ddl-auto=update
spring.h2.console.enabled=true
spring.h2.console.path=/h2
```

Mở FE:
- Serve `frontend/index.html` bằng Live Server (port 5500). FE sẽ gọi backend trước, nếu không có thì fallback localStorage.

