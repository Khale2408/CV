package com.example.cvbackend.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "education", schema = "app")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Education {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cv_id", nullable = false)
    private Cv cv;
    
    @Column(nullable = false, length = 200)
    @NotBlank
    private String degree;
    
    @Column(length = 200)
    private String school;
    
    @Column(length = 100)
    private String period;
    
    @Column(length = 50)
    private String gpa;
    
    @Column(nullable = false)
    private Integer sortOrder = 0;
    
    @OneToMany(mappedBy = "education", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<EducationBullet> bullets = new ArrayList<>();
}
