package com.example.cvbackend.repo;

import com.example.cvbackend.model.Contact;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ContactRepository extends JpaRepository<Contact, UUID> {
    List<Contact> findByCvIdOrderBySortOrderAsc(UUID cvId);
    
    @Query("SELECT c FROM Contact c WHERE c.cv.id = :cvId ORDER BY c.sortOrder ASC")
    List<Contact> findByCvIdOrdered(@Param("cvId") UUID cvId);
    
    void deleteByCvId(UUID cvId);
}
