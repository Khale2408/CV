package com.example.cvbackend.repo;

import com.example.cvbackend.model.EducationBullet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface EducationBulletRepository extends JpaRepository<EducationBullet, UUID> {
    List<EducationBullet> findByEducationIdOrderBySortOrderAsc(UUID educationId);
}
