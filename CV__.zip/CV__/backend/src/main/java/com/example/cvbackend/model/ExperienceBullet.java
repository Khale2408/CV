package com.example.cvbackend.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Entity
@Table(name = "experience_bullet", schema = "app")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExperienceBullet {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "experience_id", nullable = false)
    private Experience experience;
    
    @Column(nullable = false, length = 1000)
    @NotBlank
    private String text;
    
    @Column(nullable = false)
    private Integer sortOrder = 0;
}
