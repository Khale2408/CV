package com.example.cvbackend.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Entity
@Table(name = "contact", schema = "app")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Contact {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cv_id", nullable = false)
    private Cv cv;
    
    @Column(nullable = false, length = 32)
    @NotBlank
    @Pattern(regexp = "^(email|phone|github|linkedin|link|other)$", 
             message = "Type must be one of: email, phone, github, linkedin, link, other")
    private String type;
    
    @Column(length = 200)
    private String label;
    
    @Column(length = 1000)
    private String href;
    
    @Column(nullable = false)
    private Integer sortOrder = 0;
}
