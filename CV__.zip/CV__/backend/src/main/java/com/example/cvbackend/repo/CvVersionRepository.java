package com.example.cvbackend.repo;

import com.example.cvbackend.model.CvVersion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface CvVersionRepository extends JpaRepository<CvVersion, UUID> {
    List<CvVersion> findByCvIdOrderByCreatedAtDesc(UUID cvId);
    
    @Query("SELECT cv FROM CvVersion cv WHERE cv.cv.id = :cvId ORDER BY cv.createdAt DESC")
    List<CvVersion> findLatestVersionsByCvId(@Param("cvId") UUID cvId);
}
