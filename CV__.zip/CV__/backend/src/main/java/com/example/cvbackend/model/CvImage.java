package com.example.cvbackend.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "image", schema = "app")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CvImage {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cv_id", nullable = false)
    private Cv cv;
    
    @Column(nullable = false, length = 1000)
    @NotBlank
    private String url;
    
    @Column(length = 300)
    private String caption;
    
    @Column(nullable = false)
    private Integer sortOrder = 0;
    
    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private Instant createdAt;
}
