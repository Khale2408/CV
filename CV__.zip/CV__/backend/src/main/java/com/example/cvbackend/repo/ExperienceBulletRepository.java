package com.example.cvbackend.repo;

import com.example.cvbackend.model.ExperienceBullet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ExperienceBulletRepository extends JpaRepository<ExperienceBullet, UUID> {
    List<ExperienceBullet> findByExperienceIdOrderBySortOrderAsc(UUID experienceId);
}
