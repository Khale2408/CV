package com.example.cvbackend.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "experience", schema = "app")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Experience {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cv_id", nullable = false)
    private Cv cv;
    
    @Column(nullable = false, length = 200)
    @NotBlank
    private String title;
    
    @Column(length = 200)
    private String company;
    
    @Column(length = 100)
    private String period;
    
    @Column(length = 200)
    private String location;
    
    @Column(nullable = false)
    private Integer sortOrder = 0;
    
    @OneToMany(mappedBy = "experience", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ExperienceBullet> bullets = new ArrayList<>();
}
