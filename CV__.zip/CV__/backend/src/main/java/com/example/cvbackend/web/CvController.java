package com.example.cvbackend.web;

import com.example.cvbackend.model.*;
import com.example.cvbackend.repo.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/cv")
@RequiredArgsConstructor
@CrossOrigin(origins = {"http://localhost:5500", "http://127.0.0.1:5500", "http://localhost:8080"})
public class CvController {

    private final CvRepository cvRepo;
    private final ContactRepository contactRepo;
    private final ExperienceRepository experienceRepo;
    private final ExperienceBulletRepository expBulletRepo;
    private final EducationRepository educationRepo;
    private final EducationBulletRepository eduBulletRepo;
    private final SkillRepository skillRepo;
    private final CvImageRepository imageRepo;
    private final ObjectMapper mapper = new ObjectMapper();

    // API tương thích với frontend hiện tại (sử dụng JSON payload)
    @GetMapping("/{id}")
    public ResponseEntity<JsonNode> get(@PathVariable String id) {
        try {
            // Tìm CV theo name hoặc UUID
            Optional<Cv> cvOpt = cvRepo.findByName(id).or(() -> {
                try {
                    return cvRepo.findById(UUID.fromString(id));
                } catch (IllegalArgumentException e) {
                    return Optional.empty();
                }
            });

            if (cvOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }

            Cv cv = cvOpt.get();
            JsonNode cvJson = convertCvToJson(cv);
            return ResponseEntity.ok(cvJson);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> put(@PathVariable String id, @RequestBody JsonNode body) {
        try {
            // Tìm hoặc tạo CV
            Cv cv = cvRepo.findByName(id)
                .orElseGet(() -> {
                    try {
                        return cvRepo.findById(UUID.fromString(id)).orElse(null);
                    } catch (IllegalArgumentException e) {
                        return null;
                    }
                });

            if (cv == null) {
                cv = new Cv();
                cv.setName(id);
            }

            // Cập nhật thông tin cơ bản từ JSON
            if (body.has("name")) {
                cv.setName(body.get("name").asText());
            }
            if (body.has("title")) {
                cv.setTitle(body.get("title").asText());
            }
            if (body.has("about")) {
                cv.setAbout(body.get("about").asText());
            }
            if (body.has("avatarUrl")) {
                cv.setAvatarUrl(body.get("avatarUrl").asText());
            }

            cv = cvRepo.save(cv);

            // Cập nhật các bảng liên quan
            updateContacts(cv, body);
            updateExperiences(cv, body);
            updateEducations(cv, body);
            updateSkills(cv, body);
            updateImages(cv, body);

            return ResponseEntity.ok().build();

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // API mới cho quản lý chi tiết từng phần
    @GetMapping("/{id}/contacts")
    public ResponseEntity<List<Contact>> getContacts(@PathVariable UUID id) {
        List<Contact> contacts = contactRepo.findByCvIdOrderBySortOrderAsc(id);
        return ResponseEntity.ok(contacts);
    }

    @PostMapping("/{id}/contacts")
    public ResponseEntity<Contact> addContact(@PathVariable UUID id, @RequestBody Contact contact) {
        Cv cv = cvRepo.findById(id).orElseThrow();
        contact.setCv(cv);
        Contact saved = contactRepo.save(contact);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/{id}/experiences")
    public ResponseEntity<List<Experience>> getExperiences(@PathVariable UUID id) {
        List<Experience> experiences = experienceRepo.findByCvIdOrderBySortOrderAsc(id);
        return ResponseEntity.ok(experiences);
    }

    @GetMapping("/{id}/educations")
    public ResponseEntity<List<Education>> getEducations(@PathVariable UUID id) {
        List<Education> educations = educationRepo.findByCvIdOrderBySortOrderAsc(id);
        return ResponseEntity.ok(educations);
    }

    @GetMapping("/{id}/skills")
    public ResponseEntity<List<Skill>> getSkills(@PathVariable UUID id) {
        List<Skill> skills = skillRepo.findByCvIdOrderByCategoryAscSortOrderAsc(id);
        return ResponseEntity.ok(skills);
    }

    @GetMapping("/{id}/images")
    public ResponseEntity<List<CvImage>> getImages(@PathVariable UUID id) {
        List<CvImage> images = imageRepo.findByCvIdOrderBySortOrderAsc(id);
        return ResponseEntity.ok(images);
    }

    // Helper methods
    private JsonNode convertCvToJson(Cv cv) {
        ObjectNode cvJson = mapper.createObjectNode();
        
        cvJson.put("name", cv.getName());
        cvJson.put("title", cv.getTitle() != null ? cv.getTitle() : "");
        cvJson.put("about", cv.getAbout() != null ? cv.getAbout() : "");
        cvJson.put("avatarUrl", cv.getAvatarUrl() != null ? cv.getAvatarUrl() : "");

        // Contacts
        ObjectNode contactsJson = mapper.createObjectNode();
        cv.getContacts().forEach(contact -> {
            ObjectNode contactJson = mapper.createObjectNode();
            contactJson.put("type", contact.getType());
            contactJson.put("label", contact.getLabel() != null ? contact.getLabel() : "");
            contactJson.put("href", contact.getHref() != null ? contact.getHref() : "");
            contactsJson.set(contact.getType(), contactJson);
        });
        cvJson.set("contacts", contactsJson);

        // Experiences
        com.fasterxml.jackson.databind.node.ArrayNode experiencesJson = mapper.createArrayNode();
        cv.getExperiences().forEach(exp -> {
            ObjectNode expJson = mapper.createObjectNode();
            expJson.put("title", exp.getTitle());
            expJson.put("company", exp.getCompany() != null ? exp.getCompany() : "");
            expJson.put("period", exp.getPeriod() != null ? exp.getPeriod() : "");
            expJson.put("location", exp.getLocation() != null ? exp.getLocation() : "");
            
            com.fasterxml.jackson.databind.node.ArrayNode bulletsJson = mapper.createArrayNode();
            exp.getBullets().forEach(bullet -> bulletsJson.add(bullet.getText()));
            expJson.set("bullets", bulletsJson);
            
            experiencesJson.add(expJson);
        });
        cvJson.set("experiences", experiencesJson);

        // Educations
        com.fasterxml.jackson.databind.node.ArrayNode educationsJson = mapper.createArrayNode();
        cv.getEducations().forEach(edu -> {
            ObjectNode eduJson = mapper.createObjectNode();
            eduJson.put("degree", edu.getDegree());
            eduJson.put("school", edu.getSchool() != null ? edu.getSchool() : "");
            eduJson.put("period", edu.getPeriod() != null ? edu.getPeriod() : "");
            eduJson.put("gpa", edu.getGpa() != null ? edu.getGpa() : "");
            
            com.fasterxml.jackson.databind.node.ArrayNode bulletsJson = mapper.createArrayNode();
            edu.getBullets().forEach(bullet -> bulletsJson.add(bullet.getText()));
            eduJson.set("bullets", bulletsJson);
            
            educationsJson.add(eduJson);
        });
        cvJson.set("educations", educationsJson);

        // Skills
        ObjectNode skillsJson = mapper.createObjectNode();
        com.fasterxml.jackson.databind.node.ArrayNode hardSkillsJson = mapper.createArrayNode();
        com.fasterxml.jackson.databind.node.ArrayNode softSkillsJson = mapper.createArrayNode();
        
        cv.getSkills().forEach(skill -> {
            ObjectNode skillJson = mapper.createObjectNode();
            skillJson.put("name", skill.getName());
            skillJson.put("level", skill.getLevel());
            
            if ("hard".equals(skill.getCategory())) {
                hardSkillsJson.add(skillJson);
            } else {
                softSkillsJson.add(skillJson);
            }
        });
        
        skillsJson.set("hard", hardSkillsJson);
        skillsJson.set("soft", softSkillsJson);
        cvJson.set("skills", skillsJson);

        // Images
        com.fasterxml.jackson.databind.node.ArrayNode imagesJson = mapper.createArrayNode();
        cv.getImages().forEach(img -> {
            ObjectNode imgJson = mapper.createObjectNode();
            imgJson.put("src", img.getUrl());
            imgJson.put("caption", img.getCaption() != null ? img.getCaption() : "");
            imagesJson.add(imgJson);
        });
        cvJson.set("images", imagesJson);

        return cvJson;
    }

    private void updateContacts(Cv cv, JsonNode body) {
        if (!body.has("contacts")) return;
        
        // Xóa contacts cũ
        contactRepo.deleteByCvId(cv.getId());
        
        // Thêm contacts mới
        JsonNode contacts = body.get("contacts");
        contacts.fields().forEachRemaining(entry -> {
            JsonNode contactData = entry.getValue();
            Contact contact = new Contact();
            contact.setCv(cv);
            contact.setType(entry.getKey());
            contact.setLabel(contactData.has("label") ? contactData.get("label").asText() : "");
            contact.setHref(contactData.has("href") ? contactData.get("href").asText() : "");
            contactRepo.save(contact);
        });
    }

    private void updateExperiences(Cv cv, JsonNode body) {
        if (!body.has("experiences")) return;
        
        // Xóa experiences cũ
        experienceRepo.deleteByCvId(cv.getId());
        
        // Thêm experiences mới
        JsonNode experiences = body.get("experiences");
        for (int i = 0; i < experiences.size(); i++) {
            JsonNode expData = experiences.get(i);
            Experience exp = new Experience();
            exp.setCv(cv);
            exp.setTitle(expData.get("title").asText());
            exp.setCompany(expData.has("company") ? expData.get("company").asText() : "");
            exp.setPeriod(expData.has("period") ? expData.get("period").asText() : "");
            exp.setLocation(expData.has("location") ? expData.get("location").asText() : "");
            exp.setSortOrder(i);
            exp = experienceRepo.save(exp);
            
            // Thêm bullets
            if (expData.has("bullets")) {
                JsonNode bullets = expData.get("bullets");
                for (int j = 0; j < bullets.size(); j++) {
                    ExperienceBullet bullet = new ExperienceBullet();
                    bullet.setExperience(exp);
                    bullet.setText(bullets.get(j).asText());
                    bullet.setSortOrder(j);
                    expBulletRepo.save(bullet);
                }
            }
        }
    }

    private void updateEducations(Cv cv, JsonNode body) {
        if (!body.has("educations")) return;
        
        // Xóa educations cũ
        educationRepo.deleteByCvId(cv.getId());
        
        // Thêm educations mới
        JsonNode educations = body.get("educations");
        for (int i = 0; i < educations.size(); i++) {
            JsonNode eduData = educations.get(i);
            Education edu = new Education();
            edu.setCv(cv);
            edu.setDegree(eduData.get("degree").asText());
            edu.setSchool(eduData.has("school") ? eduData.get("school").asText() : "");
            edu.setPeriod(eduData.has("period") ? eduData.get("period").asText() : "");
            edu.setGpa(eduData.has("gpa") ? eduData.get("gpa").asText() : "");
            edu.setSortOrder(i);
            edu = educationRepo.save(edu);
            
            // Thêm bullets
            if (eduData.has("bullets")) {
                JsonNode bullets = eduData.get("bullets");
                for (int j = 0; j < bullets.size(); j++) {
                    EducationBullet bullet = new EducationBullet();
                    bullet.setEducation(edu);
                    bullet.setText(bullets.get(j).asText());
                    bullet.setSortOrder(j);
                    eduBulletRepo.save(bullet);
                }
            }
        }
    }

    private void updateSkills(Cv cv, JsonNode body) {
        if (!body.has("skills")) return;
        
        // Xóa skills cũ
        skillRepo.deleteByCvId(cv.getId());
        
        // Thêm skills mới
        JsonNode skills = body.get("skills");
        
        // Hard skills
        if (skills.has("hard")) {
            JsonNode hardSkills = skills.get("hard");
            for (int i = 0; i < hardSkills.size(); i++) {
                JsonNode skillData = hardSkills.get(i);
                Skill skill = new Skill();
                skill.setCv(cv);
                skill.setName(skillData.get("name").asText());
                skill.setLevel((byte) skillData.get("level").asInt());
                skill.setCategory("hard");
                skill.setSortOrder(i);
                skillRepo.save(skill);
            }
        }
        
        // Soft skills
        if (skills.has("soft")) {
            JsonNode softSkills = skills.get("soft");
            for (int i = 0; i < softSkills.size(); i++) {
                JsonNode skillData = softSkills.get(i);
                Skill skill = new Skill();
                skill.setCv(cv);
                skill.setName(skillData.get("name").asText());
                skill.setLevel((byte) skillData.get("level").asInt());
                skill.setCategory("soft");
                skill.setSortOrder(i);
                skillRepo.save(skill);
            }
        }
    }

    private void updateImages(Cv cv, JsonNode body) {
        if (!body.has("images")) return;
        
        // Xóa images cũ
        imageRepo.deleteByCvId(cv.getId());
        
        // Thêm images mới
        JsonNode images = body.get("images");
        for (int i = 0; i < images.size(); i++) {
            JsonNode imgData = images.get(i);
            CvImage img = new CvImage();
            img.setCv(cv);
            img.setUrl(imgData.get("src").asText());
            img.setCaption(imgData.has("caption") ? imgData.get("caption").asText() : "");
            img.setSortOrder(i);
            imageRepo.save(img);
        }
    }
}