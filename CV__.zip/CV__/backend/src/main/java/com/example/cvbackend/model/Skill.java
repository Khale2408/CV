package com.example.cvbackend.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Entity
@Table(name = "skill", schema = "app")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Skill {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cv_id", nullable = false)
    private Cv cv;
    
    @Column(nullable = false, length = 200)
    @NotBlank
    private String name;
    
    @Column(nullable = false)
    @Min(value = 0, message = "Level must be between 0 and 100")
    @Max(value = 100, message = "Level must be between 0 and 100")
    private Byte level;
    
    @Column(nullable = false, length = 16)
    @Pattern(regexp = "^(hard|soft)$", message = "Category must be either 'hard' or 'soft'")
    private String category;
    
    @Column(nullable = false)
    private Integer sortOrder = 0;
}
